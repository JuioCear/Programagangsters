<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" type="text/css" href="login.css">
</head>
<body id="diva" class="text-white">

<?php
  session_start();
  if (isset($_SESSION['nombredeusuario'])) {
    header("Location: ");
  }

  if (isset($_POST['Iniciarsesion'])) {

    $correo=$_POST['correo'];
    $contra=$_POST['contra'];
    $nombredeusuario=$_POST['nomusu'];

    $nombrebd= "..//dbDgo.db";
    $db=new SQLITE3($nombrebd);

    $sql="insert into . () values ();";
    $result= $db->query($sql);

    $registros= $db->query("select * from .");

  if (!isset($_SESSION['nombredeusuario'])) {
    

    if ($reg=mysqli_fetch_array($registros)) {
      $_SESSION['nombredeusuario']=$_REQUEST['Nom_usuario'];
      header("Location: ");
    }
    else {echo "El usuario y/o contraseña son equivocados";}
  }
}
  ?>

<div class="container mt-3" id="hola">
  <h2 class="text-white bg-primary p-3"><center>Iniciar sesion en Dgo!Artist</center></h2>
  <form action="/action_page.php">
    <div class="mb-3 mt-3">
      <label for="email">Correo Electronico:</label>
      <input type="email" class="form-control" id="Correo" placeholder="Ingrese correo electronico" name="Correo">
    </div>
    <div class="mb-3">
      <label for="pwd">Contraseña:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Ingrese su contraseña:" name="Contraseña">
    </div>
    <div class="mb-3 mt-3">
      <label for="Nom_usuario">Nombre de usuario:</label>
      <input type="text" class="form-control" id="Nom_usuario" placeholder="Ingrese un nombre de usuario" name="Nom_usuario">
    </div>
    <button type="submit" class="btn btn-primary" id="boton" name="Iniciarsesion">Iniciar sesion</button>
  </form>
</div>
