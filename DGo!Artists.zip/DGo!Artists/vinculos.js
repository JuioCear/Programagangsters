window.addEventListener("load",inicio,false);

function inicio(){
	var ob=document.getElementById('');
}